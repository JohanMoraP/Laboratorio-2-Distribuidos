import UploadForm from "./UploadForm";

const uploadImage = async (file) => {
  const formData = new FormData();
  formData.append("image", file);

  const response = await fetch(`${import.meta.env.VITE_API_URL}/upload`, {
    method: "POST",
    body: formData
  });

  const data = await response.json();
  return data.url;
};

const App = () => {
  const handleUpload = async (file) => {
    try {
      const imageUrl = await uploadImage(file);
      console.log("Imagen subida:", imageUrl);
      // Aquí puedes actualizar el estado para mostrar la imagen en la UI
    } catch (error) {
      console.error("Error subiendo imagen:", error);
    }
  };

  return (
    <div>
      <h1>Gestor de imágenes</h1>
      <UploadForm onUpload={handleUpload} />
    </div>
  );
};

export default App;
