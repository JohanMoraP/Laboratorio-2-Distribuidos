const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const STORAGE_PATH = '/storage';
const MAX_SIZE = 100 * 1024 * 1024; // 100 MB

if (!fs.existsSync(STORAGE_PATH)) fs.mkdirSync(STORAGE_PATH);

app.get('/space', (req, res) => {
    const files = fs.readdirSync(STORAGE_PATH);
    const totalSize = files.reduce((acc, file) => acc + fs.statSync(path.join(STORAGE_PATH, file)).size, 0);
    res.json({ space: MAX_SIZE - totalSize });
});

app.post('/store', express.raw({ type: 'image/*', limit: '10mb' }), (req, res) => {
    const filename = `img_${Date.now()}.jpg`;
    fs.writeFileSync(path.join(STORAGE_PATH, filename), req.body);
    res.json({ filename });
});

app.listen(4000, () => console.log('Storage node running on port 4000'));
