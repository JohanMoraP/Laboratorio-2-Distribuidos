require('dotenv').config();
const express = require('express');
const multer = require('multer');
const axios = require('axios');
const { Pool } = require('pg');

const app = express();
app.use(express.json());

const pool = new Pool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
});

let storageNodes = [];

// Cargar nodos de almacenamiento desde el archivo .env
const loadStorageNodes = () => {
    const nodes = process.env.IPS; // Ejemplo: "http://192.168.1.10:4000,http://192.168.1.11:4000"
    if (nodes) {
        storageNodes = nodes.split(','); // Convertir string en array
    } else {
        console.error('No storage nodes found in .env file');
        process.exit(1); // Salir si no se encuentran nodos
    }
};

loadStorageNodes();

app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
});

app.get("/", (req, res) => {
    res.send("Middleware funcionando!");
});


app.post('/upload', multer().single('image'), async (req, res) => {
    if (!req.file) return res.status(400).send('No image provided');

    let bestNode = null;
    let maxSpace = 0;

    for (const node of storageNodes) {
        try {
            const response = await axios.get(`${node}/space`);
            if (response.data.space > maxSpace) {
                maxSpace = response.data.space;
                bestNode = node;
            }
        } catch (error) {
            console.error(`Error consultando ${node}`);
        }
    }

    if (!bestNode) return res.status(500).send('No storage node available');

    try {
        const uploadResponse = await axios.post(`${bestNode}/store`, req.file);
        const imageUrl = `${bestNode}/${uploadResponse.data.filename}`;

        await pool.query(
            'INSERT INTO images (filename, url, node) VALUES ($1, $2, $3)',
            [req.file.originalname, imageUrl, bestNode]
        );

        res.send({ success: true, url: imageUrl });
    } catch (error) {
        res.status(500).send('Error uploading image');
    }
});

app.listen(3000, () => console.log('Middleware running on port 3000'));
