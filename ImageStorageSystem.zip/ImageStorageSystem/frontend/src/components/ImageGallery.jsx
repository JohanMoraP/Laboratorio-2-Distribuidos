import React, { useEffect, useState } from "react";
import ImageCard from "./ImageCard";

const ImageGallery = () => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        const response = await fetch(`${import.meta.env.VITE_API_URL}/images`);
        if (!response.ok) throw new Error("Error al obtener imágenes");
        
        const data = await response.json();
        setImages(data);
      } catch (error) {
        console.error("Error al obtener imágenes:", error);
      }
    };

    fetchImages();
  }, []);

  return (
    <div className="container mt-4">
      <h2>Imágenes almacenadas</h2>
      <div className="row">
        {images.length > 0 ? (
          images.map((img, index) => (
            <div className="col-md-3" key={index}>
              <ImageCard imageUrl={img.url} imageName={img.filename} />
            </div>
          ))
        ) : (
          <p>No hay imágenes almacenadas.</p>
        )}
      </div>
    </div>
  );
};

export default ImageGallery;
